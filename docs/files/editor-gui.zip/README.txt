DialBB Scenario Editor

This is a GUI scenario editor for DialBB-NC.
This program is licensed under MIT License.

The project main page is at: https://github.com/c4a-ri/dialbb-scenario-editor
License information of depedent projects can be found in licenses.json



